# Test data

The following blobs originate from the [linuxhw/EDID] repository and are
licensed under the [Creative Commons Attribution 4.0 International][CC-BY-4.0]
license:

- acer-p1276
- goldstar-ite6604-hdmi
- msi-mag321curv-dp
- panasonic-mei96a2-dp
- samsung-s27a950d-dp
- sun-gh19ps-dvi
- viewsonic-vp2768-dp

The other blobs are under the same license as the rest of the libdisplay-info
project.

[linuxhw/EDID]: https://github.com/linuxhw/EDID
[CC-BY-4.0]: LICENSE.CC-BY-4.0
